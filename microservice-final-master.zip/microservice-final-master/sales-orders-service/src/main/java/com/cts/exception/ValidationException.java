package com.cts.exception;

public class ValidationException extends RuntimeException{
	
	public ValidationException(String mesage) {
        super(mesage);
    }

}
