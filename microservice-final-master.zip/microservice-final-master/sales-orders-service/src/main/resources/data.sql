INSERT INTO 
	CUSTOMER_SOS (cust_id,cust_email,cust_first_name, cust_last_name) 
VALUES
  	(1,'sarath.s@gmail.com','sarath', 'surapaneni'),
  (2,'surya.k@email.com','surya','k');
  	
  