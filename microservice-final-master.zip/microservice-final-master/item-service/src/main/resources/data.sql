INSERT INTO 
	ITEM (name,description, price) 
VALUES
  	('iPhone7','Features new camera systems, a better battery-life, an efficient processor and powerful stereo speakers', '25000'),
  	('iPhone6', 'Features new camera systems, a better battery-life, an efficient processor and powerful stereo speakers', '23000');