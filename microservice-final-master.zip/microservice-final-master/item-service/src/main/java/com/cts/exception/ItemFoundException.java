package com.cts.exception;

/**
 * 
 * ItemFoundException
 *
 */
public class ItemFoundException extends RuntimeException{

	public ItemFoundException(String mesage) {
        super(mesage);
    }
}
