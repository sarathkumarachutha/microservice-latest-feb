INSERT INTO 
	CUSTOMER (email,first_name, last_name) 
VALUES
  	('sarath.s@gmail.com','sarath', 'surapaneni'),
  	('surya.k@email.com','surya','k');